const { SlowBuffer } = require('buffer');
const os = require('os');

// Platform
console.log(os.platform());

// CPU Arch
console.log(os.arch());

// CPU Core info
console.log(os.cpus());

// Free memory
console.log(os.freemem());

// Total memory
console.log(os.totalmem());

// Home directroy
console.log(os.homedir());

// Uptime (time system has been up)
console.log(os.uptime());